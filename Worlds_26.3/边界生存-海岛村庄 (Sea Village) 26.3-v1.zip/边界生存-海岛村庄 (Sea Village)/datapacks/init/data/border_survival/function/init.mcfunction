execute in minecraft:overworld run spawnpoint @s -2590 71 -35286 90 0
execute in minecraft:overworld run tp @s -2590 71 -35286 90 0