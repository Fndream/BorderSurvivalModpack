execute in minecraft:overworld run spawnpoint @s -166 104 132 0 0
execute in minecraft:overworld run tp @s -166 104 132 0 0