spawnpoint @s 1231 101 -461 90 0
tp @s 1231 101 -461 90 0