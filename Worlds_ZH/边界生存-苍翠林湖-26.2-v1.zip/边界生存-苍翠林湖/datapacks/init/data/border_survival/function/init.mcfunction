spawnpoint @s -40 67 -51 0 0
tp @s -40 67 -51 0 0