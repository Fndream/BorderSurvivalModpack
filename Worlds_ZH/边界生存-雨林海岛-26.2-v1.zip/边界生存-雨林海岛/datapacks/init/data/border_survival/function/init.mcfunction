spawnpoint @s -94 64 49 -90 0
tp @s -94 64 49 -90 0