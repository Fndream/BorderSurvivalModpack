spawnpoint @s 1253 66 -331 90 0
tp @s 1253 66 -331 90 0