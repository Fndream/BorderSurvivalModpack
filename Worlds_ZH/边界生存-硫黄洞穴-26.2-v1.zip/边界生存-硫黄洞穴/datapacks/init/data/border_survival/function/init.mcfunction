spawnpoint @s 2 -6 -4 90 0
tp @s 2 -6 -4 90 0