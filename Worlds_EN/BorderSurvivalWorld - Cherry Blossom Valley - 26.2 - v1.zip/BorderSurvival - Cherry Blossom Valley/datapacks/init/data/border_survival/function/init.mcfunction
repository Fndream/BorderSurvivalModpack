spawnpoint @s 72 98 -41
tp @s 72 98 -41 -90 0