spawnpoint @s -15 103 -695 0 0
tp @s -15 103 -695 0 0