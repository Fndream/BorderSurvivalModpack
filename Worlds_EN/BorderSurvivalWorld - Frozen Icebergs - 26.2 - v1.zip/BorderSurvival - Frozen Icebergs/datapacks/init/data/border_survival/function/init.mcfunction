spawnpoint @s 19 236 101 0 0
tp @s 19 236 101 0 0