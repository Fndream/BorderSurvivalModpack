spawnpoint @s 3 63 0
tp @s 3 47 -1 0 0