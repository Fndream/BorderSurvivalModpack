spawnpoint @s 0 65 0 -90 0
tp @s 0 65 0 -90 0