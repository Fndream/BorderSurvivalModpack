spawnpoint @s 258 152 25 90 0
tp @s 258 152 25 90 0